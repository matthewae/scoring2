<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penilaian Project - Scoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <script>
        const tahapanOrder = [
            'Pra-Tender',
            'Tender',
            'Persiapan Pelaksanaan Pekerjaan Konstruksi',
            'Pelaksanaan Pekerjaan Konstruksi',
            'Penunjang Tahapan Pelaksanaan Konstruksi (PELAPORAN)',
            'Perubahan Kontrak (Addendum)',
            'Kontrak Kritis',
            'Pemutusan Kontrak sampai dengan Penetapan Sanksi Daftar Hitam'
        ];

        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Swiper
            const swiper = new Swiper('.swiper-container', {
                slidesPerView: 'auto',
                spaceBetween: 16,
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
                breakpoints: {
                    640: { slidesPerView: 2 },
                    768: { slidesPerView: 3 },
                    1024: { slidesPerView: 4 }
                }
            });

            // Sort tahapan slides
            const slides = Array.from(document.querySelectorAll('.swiper-slide'));
            slides.sort((a, b) => {
                const aIndex = tahapanOrder.indexOf(a.querySelector('button').textContent.trim());
                const bIndex = tahapanOrder.indexOf(b.querySelector('button').textContent.trim());
                return aIndex - bIndex;
            });
            const swiperWrapper = document.querySelector('.swiper-wrapper');
            slides.forEach(slide => swiperWrapper.appendChild(slide));

            // Show first tahapan by default
            if (tabs.length > 0) {
                showTahapan(tabs[0].getAttribute('data-tahapan'));
            }
        });

        function showTahapan(tahapan) {
            // Hide all content
            document.querySelectorAll('.tahapan-content').forEach(content => {
                content.classList.add('hidden');
            });
            // Remove active class from all tabs
            document.querySelectorAll('.tahapan-tab').forEach(tab => {
                tab.classList.remove('bg-blue-500', 'text-white');
                tab.classList.add('bg-gray-100', 'text-gray-600');
            });
            // Show selected content and activate tab
            const selectedContent = document.getElementById('tahapan-' + tahapan.toLowerCase().replace(/ /g, '-'));
            const selectedTab = document.querySelector(`[data-tahapan="${tahapan}"]`);
            if (selectedContent) selectedContent.classList.remove('hidden');
            if (selectedTab) {
                selectedTab.classList.remove('bg-gray-100', 'text-gray-600');
                selectedTab.classList.add('bg-blue-500', 'text-white');
            }
        }
    </script>
    <style>
        .gradient-background {
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            transform: scale(0.98);
            transition: transform 0.3s ease;
        }
        .swiper-container {
            padding: 0 40px;
            margin: 0 -40px;
        }
        .swiper-slide {
            width: auto;
            transition: all 0.3s ease;
        }
        .swiper-button-next,
        .swiper-button-prev {
            color: #4B5563;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        .swiper-button-next:hover,
        .swiper-button-prev:hover {
            background: rgba(255, 255, 255, 1);
            color: #1F2937;
        }
        .gradient-background:hover {
            transform: scale(0.99);
        }
        .glass-effect {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transform: scale(0.98);
            transition: all 0.3s ease;
        }
        .score-card {
            transition: all 0.3s ease;
        }
        .score-card:hover {
            transform: translateY(-2px);
        }
        .sidebar {
            transition: transform 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Particles Background -->
    <div id="particles-js" class="fixed inset-0 -z-10 opacity-50"></div>

    <!-- Sidebar Toggle Button (Mobile) -->
    <button id="sidebarToggle" class="fixed top-4 left-4 z-50 md:hidden bg-white p-2 rounded-lg shadow-lg">
        <i class="fas fa-bars text-gray-800"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar fixed top-0 left-0 h-full w-56 glass-effect z-40 transform md:translate-x-0">
        <div class="p-6">
            <div class="flex items-center justify-center mb-8">
                <h1 class="text-2xl font-bold text-gray-800">Scoring System</h1>
            </div>
            <nav class="space-y-4">
                <a href="<?php echo e(route('dashboard.guest.index')); ?>" class="flex items-center space-x-3 text-gray-800 hover:bg-gray-100 p-3 rounded-lg transition-all duration-300">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo e(route('dashboard.guest.project-documents.create')); ?>" class="flex items-center space-x-3 text-gray-800 hover:bg-gray-100 p-3 rounded-lg transition-all duration-300">
                    <i class="fas fa-file-upload"></i>
                    <span>Pengajuan Dokumen</span>
                </a>
                <a href="<?php echo e(route('dashboard.guest.project-documents.history')); ?>" class="flex items-center space-x-3 text-gray-800 hover:bg-gray-100 p-3 rounded-lg transition-all duration-300">
                    <i class="fas fa-history"></i>
                    <span>Riwayat Pengajuan</span>
                </a>
                <a href="<?php echo e(route('dashboard.guest.guide')); ?>" class="flex items-center space-x-3 text-gray-800 hover:bg-gray-100 p-3 rounded-lg transition-all duration-300">
                    <i class="fas fa-book"></i>
                    <span>Panduan</span>
                </a>
            </nav>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="md:ml-64 p-8">
        <!-- Back Button -->
        <a href="<?php echo e(route('dashboard.guest.project-scores.index')); ?>" class="inline-flex items-center text-gray-600 hover:text-gray-800 mb-6 transition-colors duration-300">
            <i class="fas fa-arrow-left mr-2"></i>
            Kembali ke Daftar Project
        </a>

        <!-- Project Header -->
        <div class="gradient-background rounded-2xl shadow-lg p-8 mb-12">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h1 class="text-4xl font-bold text-gray-800 mb-2"><?php echo e($project->name); ?></h1>
                    <p class="text-gray-600"><?php echo e($project->description); ?></p>
                </div>
                <span class="px-4 py-2 rounded-full text-sm <?php echo e($project->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                    <?php echo e(ucfirst($project->status)); ?>

                </span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div class="flex items-center space-x-2 text-gray-600">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Dibuat: <?php echo e($project->created_at->format('d M Y')); ?></span>
                </div>
                <div class="flex items-center space-x-2 text-gray-600">
                    <i class="fas fa-clock"></i>
                    <span>Terakhir diupdate: <?php echo e($project->updated_at->format('d M Y')); ?></span>
                </div>
                <!-- <div class="flex items-center space-x-2 text-gray-600">
                    <i class="fas fa-user"></i>
                    <span>Penanggung Jawab: <?php echo e($project->user->name); ?></span> -->
            </div>

            <!-- Project Details -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-4">
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-map-marker-alt mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Lokasi</h4>
                            <p class="text-gray-600"><?php echo e($project->location); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-money-bill-wave mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Nilai Kontrak</h4>
                            <p class="text-gray-600">Rp <?php echo e(number_format($project->contract_value, 2, ',', '.')); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-calendar-check mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Tanggal SPMK</h4>
                            <p class="text-gray-600"><?php echo e($project->spmk_date ? $project->spmk_date->format('d M Y') : '-'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-hourglass-half mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Durasi</h4>
                            <p class="text-gray-600"><?php echo e($project->duration_days); ?> hari</p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-building mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Kementerian/Lembaga</h4>
                            <p class="text-gray-600"><?php echo e($project->ministry_institution); ?></p>
                        </div>
                    </div>
                </div>

                <div class="space-y-4">
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-user-tie mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Konsultan Perencana</h4>
                            <p class="text-gray-600"><?php echo e($project->planning_consultant); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-user-shield mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Konsultan MK</h4>
                            <p class="text-gray-600"><?php echo e($project->mk_consultant); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-hard-hat mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Kontraktor</h4>
                            <p class="text-gray-600"><?php echo e($project->contractor); ?></p>
                        </div>
                    </div>
                    <div class="flex items-start space-x-2">
                        <i class="fas fa-tasks mt-1 text-gray-600"></i>
                        <div>
                            <h4 class="font-semibold text-gray-700">Metode Pemilihan</h4>
                            <p class="text-gray-600"><?php echo e($project->selection_method); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Overall Project Status -->
        <div class="glass-effect rounded-2xl p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Status Keseluruhan Project</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <?php
                    $totalApproved = 0;
                    $totalPending = 0;
                    foreach($tahapanData as $data) {
                        $totalApproved += $data['approved'];
                        $totalPending += $data['pending'];
                    }
                    $totalDocs = $totalApproved + $totalPending;
                    $approvedPercentage = $totalDocs > 0 ? round(($totalApproved / $totalDocs) * 100) : 0;
                ?>
                <div class="glass-effect rounded-xl p-6 text-center">
                    <div class="text-4xl font-bold text-green-600 mb-2"><?php echo e($totalApproved); ?></div>
                    <div class="text-gray-600">Dokumen Disetujui</div>
                </div>
                <div class="glass-effect rounded-xl p-6 text-center">
                    <div class="text-4xl font-bold text-yellow-600 mb-2"><?php echo e($totalPending); ?></div>
                    <div class="text-gray-600">Dokumen Pending</div>
                </div>
                <div class="glass-effect rounded-xl p-6 text-center">
                    <div class="text-4xl font-bold text-blue-600 mb-2"><?php echo e($approvedPercentage); ?>%</div>
                    <div class="text-gray-600">Progress Keseluruhan</div>
                </div>
            </div>
        </div>

        <!-- Document Status by Phase -->
        <div class="glass-effect rounded-2xl p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Status Dokumen per Tahapan</h2>
            <div class="swiper-container mb-6">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $tahapanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahapan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <button 
                                onclick="showTahapan('<?php echo e($tahapan); ?>')"
                                class="tahapan-tab w-full px-6 py-3 rounded-lg font-semibold transition-all duration-300"
                                data-tahapan="<?php echo e($tahapan); ?>"
                            >
                                <?php echo e($tahapan); ?>

                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

            <?php $__currentLoopData = $tahapanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahapan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div 
                    id="tahapan-<?php echo e(Str::slug($tahapan)); ?>" 
                    class="tahapan-content hidden"
                >
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="glass-effect rounded-xl p-6">
                            <div class="relative" style="height: 300px;">
                                <canvas id="chart-<?php echo e(Str::slug($tahapan)); ?>"></canvas>
                            </div>
                        </div>
                        <div class="glass-effect rounded-xl p-6">
                            <div class="grid grid-cols-2 gap-4">
                                <div class="text-center p-4 rounded-lg bg-green-50">
                                    <div class="text-3xl font-bold text-green-600"><?php echo e($data['approved']); ?></div>
                                    <div class="text-gray-600 mt-2">Disetujui</div>
                                </div>
                                <div class="text-center p-4 rounded-lg bg-yellow-50">
                                    <div class="text-3xl font-bold text-yellow-600"><?php echo e($data['pending']); ?></div>
                                    <div class="text-gray-600 mt-2">Pending</div>
                                </div>
                            </div>
                            <div class="mt-6">
                                <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                    <?php
                                        $total = $data['approved'] + $data['pending'];
                                        $percentage = $total > 0 ? ($data['approved'] / $total) * 100 : 0;
                                    ?>
                                    <div 
                                        class="bg-green-600 h-full transition-all duration-500" 
                                        style="width: <?php echo e($percentage); ?>%"
                                    ></div>
                                </div>
                                <div class="text-center mt-2 text-gray-600">
                                    Progress: <?php echo e(round($percentage)); ?>%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        </div>

        <!-- End of Document Status by Phase -->
    </main>

    <script>
        // Initialize particles.js
        particlesJS.load('particles-js', '/js/particles-config.js');

        // Mobile sidebar toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>
                </div>
                <div class="glass-effect rounded-xl p-6 text-center">
                    <div class="text-4xl font-bold text-yellow-600 mb-2"><?php echo e($totalPending); ?></div>
                    <div class="text-gray-600">Dokumen Pending</div>
                </div>
                <div class="glass-effect rounded-xl p-6 text-center">
                    <div class="text-4xl font-bold text-blue-600 mb-2"><?php echo e($approvedPercentage); ?>%</div>
                    <div class="text-gray-600">Progress Keseluruhan</div>
                </div>
            </div>
        </div>

        <!-- Document Status by Phase -->
        <div class="glass-effect rounded-2xl p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Status Dokumen per Tahapan</h2>
            <div class="swiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $tahapanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahapan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="w-full p-4">
                                <h3 class="text-xl font-bold text-gray-800 mb-4"><?php echo e($tahapan); ?></h3>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div class="glass-effect rounded-xl p-6">
                                        <div class="relative" style="height: 300px;">
                                            <canvas id="chart-<?php echo e(Str::slug($tahapan)); ?>"></canvas>
                                        </div>
                                    </div>
                                    <div class="glass-effect rounded-xl p-6">
                                        <div class="grid grid-cols-2 gap-4">
                                            <div class="text-center p-4 rounded-lg bg-green-50">
                                                <div class="text-3xl font-bold text-green-600"><?php echo e($data['approved']); ?></div>
                                                <div class="text-gray-600 mt-2">Disetujui</div>
                                            </div>
                                            <div class="text-center p-4 rounded-lg bg-yellow-50">
                                                <div class="text-3xl font-bold text-yellow-600"><?php echo e($data['pending']); ?></div>
                                                <div class="text-gray-600 mt-2">Pending</div>
                                            </div>
                                        </div>
                                        <div class="mt-6">
                                            <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                                <?php
                                                    $total = $data['approved'] + $data['pending'];
                                                    $percentage = $total > 0 ? ($data['approved'] / $total) * 100 : 0;
                                                ?>
                                                <div 
                                                    class="bg-green-600 h-full transition-all duration-500" 
                                                    style="width: <?php echo e($percentage); ?>%"
                                                ></div>
                                            </div>
                                            <div class="text-center mt-2 text-gray-600">
                                                Progress: <?php echo e(round($percentage)); ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>

            <?php $__empty_1 = true; $__currentLoopData = $groupedDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahapan => $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-12">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6"><?php echo e($tahapan); ?></h2>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $document = $project->projectDocuments->where('document_type_code', $type->code)->first();
                                $score = $document && $document->score >= 60 ? 1 : 0;
                                $status = $score == 1 ? 'approved' : 'pending';
                            ?>
                            <div class="glass-effect score-card rounded-2xl p-6">
                                <div class="flex justify-between items-start mb-6">
                                    <div class="flex items-center space-x-4">
                                        <div class="text-3xl <?php echo e($status === 'approved' ? 'text-green-600' : 'text-yellow-600'); ?>">
                                            <i class="fas <?php echo e($status === 'approved' ? 'fa-check-circle' : 'fa-clock'); ?>"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-xl font-bold text-gray-800"><?php echo e($type->uraian); ?></h3>
                                            <p class="text-gray-500"><?php echo e($type->code); ?></p>
                                            <span class="inline-block px-3 py-1 mt-2 text-sm rounded-full <?php echo e($status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                <?php echo e($status === 'approved' ? 'Disetujui' : 'Pending'); ?>

                                            </span>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-2xl font-bold <?php echo e($score == 1 ? 'text-green-600' : 'text-red-600'); ?>">
                                            <?php echo e($score); ?>

                                        </div>
                                        <div class="text-sm text-gray-500">Skor</div>
                                    </div>
                                </div>

                    <?php if($document && $document->assessment_notes): ?>
                        <div class="bg-gray-50 rounded-xl p-4 mb-4">
                            <h4 class="font-semibold text-gray-700 mb-2">Catatan Penilaian:</h4>
                            <p class="text-gray-600"><?php echo e($document->assessment_notes); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-calendar-check"></i>
                            <span>Dinilai pada: <?php echo e($document && $document->assessed_at ? $document->assessed_at->format('d M Y') : 'Belum dinilai'); ?></span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-user"></i>
                            <span>Penilai: <?php echo e($document && $document->assessor ? $document->assessor->name : 'Belum ditentukan'); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-12">
                    <div class="text-6xl text-gray-400 mb-4">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">Belum Ada Dokumen</h3>
                    <p class="text-gray-500">Project ini belum memiliki dokumen yang dinilai</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <style>
        .swiper {
            width: 100%;
            height: 100%;
            margin-left: auto;
            margin-right: auto;
        }
        .swiper-slide {
            text-align: center;
            background: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .swiper-button-next,
        .swiper-button-prev {
            color: #4B5563;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 50%;
            width: 40px;
            height: 40px;
        }
        .swiper-pagination-bullet {
            background: #4B5563;
        }
        .swiper-pagination-bullet-active {
            background: #3B82F6;
        }
    </style>

    <script>
        // Tab functionality
        function showTahapan(tahapan) {
            // Hide all content
            document.querySelectorAll('.tahapan-content').forEach(content => {
                content.classList.remove('active');
                content.classList.add('hidden');
            });

            // Remove active class from all tabs
            document.querySelectorAll('.tahapan-tab').forEach(tab => {
                tab.classList.remove('active');
            });

            // Show selected content
            const selectedContent = document.getElementById('tahapan-' + tahapan.toLowerCase().replace(/ /g, '-'));
            selectedContent.classList.remove('hidden');
            setTimeout(() => selectedContent.classList.add('active'), 50);

            // Activate selected tab
            document.querySelector(`[data-tahapan="${tahapan}"]`).classList.add('active');
        }

        // Show first tab by default
        document.addEventListener('DOMContentLoaded', () => {
            const firstTab = document.querySelector('.tahapan-tab');
            if (firstTab) {
                const firstTahapan = firstTab.getAttribute('data-tahapan');
                showTahapan(firstTahapan);
            }
        });


        // Initialize Swiper
        const swiper = new Swiper('.swiper', {
            slidesPerView: 1,
            spaceBetween: 30,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });

        // Initialize Charts
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Charts
            <?php $__currentLoopData = $tahapanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahapan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                new Chart(document.getElementById('chart-<?php echo e(Str::slug($tahapan)); ?>').getContext('2d'), {
                    type: 'pie',
                    data: {
                        labels: ['Disetujui', 'Pending'],
                        datasets: [{
                            data: [<?php echo e($data['approved']); ?>, <?php echo e($data['pending']); ?>],
                            backgroundColor: ['#10B981', '#F59E0B'],
                            borderWidth: 0,
                            hoverOffset: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    font: {
                                        size: 14,
                                        weight: 'bold'
                                    },
                                    generateLabels: function(chart) {
                                        const data = chart.data;
                                        if (data.labels.length && data.datasets.length) {
                                            return data.labels.map(function(label, i) {
                                                const value = data.datasets[0].data[i];
                                                const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                                                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                                return {
                                                    text: `${label} (${percentage}% - ${value} dokumen)`,
                                                    fillStyle: data.datasets[0].backgroundColor[i],
                                                    hidden: isNaN(value) || value === 0,
                                                    index: i
                                                };
                                            });
                                        }
                                        return [];
                                    }
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const value = context.raw;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                        return `${context.label}: ${value} dokumen (${percentage}%)`;
                                    }
                                },
                                padding: 16,
                                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                                titleFont: {
                                    size: 14,
                                    weight: 'bold'
                                },
                                bodyFont: {
                                    size: 14
                                }
                            }
                        },
                        animation: {
                            animateScale: true,
                            animateRotate: true,
                            duration: 2000,
                            easing: 'easeOutQuart'
                        }
                    }
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Sort tahapan based on predefined order
            const tabContainer = document.querySelector('.swiper-wrapper');
            const slides = Array.from(tabContainer.children);
            slides.sort((a, b) => {
                const aText = a.querySelector('h3').textContent.trim();
                const bText = b.querySelector('h3').textContent.trim();
                const aIndex = tahapanOrder.indexOf(aText);
                const bIndex = tahapanOrder.indexOf(bText);
                return aIndex - bIndex;
            });
            slides.forEach(slide => tabContainer.appendChild(slide));
        });


        // Sort tahapan buttons
        const tabContainer = document.querySelector('.flex.space-x-4.mb-6');
        const tabs = Array.from(tabContainer.children);
        tabs.sort((a, b) => {
            const aIndex = tahapanOrder.indexOf(a.textContent.trim());
            const bIndex = tahapanOrder.indexOf(b.textContent.trim());
            return aIndex - bIndex;
        });
        tabs.forEach(tab => tabContainer.appendChild(tab));

        // Show first tahapan by default
        if (tabs.length > 0) {
            showTahapan(tabs[0].getAttribute('data-tahapan'));
        }
    });

        // Initialize Particles.js
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: ['#6B7280', '#9CA3AF', '#4B5563'] },
                shape: { type: ['circle', 'triangle'] },
                opacity: { value: 0.2, random: true, anim: { enable: true, speed: 0.5, opacity_min: 0.1, sync: false } },
                size: { value: 2, random: true, anim: { enable: true, speed: 2, size_min: 0.1, sync: false } },
                line_linked: { enable: true, distance: 150, color: '#6B7280', opacity: 0.15, width: 1 },
                move: { enable: true, speed: 1.5, direction: 'none', random: true, straight: false, out_mode: 'out', bounce: false, attract: { enable: true, rotateX: 600, rotateY: 1200 } }
            },
            interactivity: {
                detect_on: 'canvas',
                events: { onhover: { enable: true, mode: 'bubble' }, onclick: { enable: true, mode: 'push' }, resize: true },
                modes: { bubble: { distance: 200, size: 3.5, duration: 2, opacity: 0.6 }, push: { particles_nb: 6 } }
            },
            retina_detect: true
        });

        // Sidebar Toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html><?php /**PATH C:\laragon\www\scoring2\resources\views/dashboard/guest/project-scores/show.blade.php ENDPATH**/ ?>